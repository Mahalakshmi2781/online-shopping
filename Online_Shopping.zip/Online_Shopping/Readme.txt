How to run project?
Step 1: Extract/unzip the file
Step 2: Go inside the project folder, open cmd and type the following commands to install Django Framework and run the webserver:
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
Step 3: Finally, open the browser and go to http://127.0.0.1:8000/

Admin loging
user id = Admin
password= 123